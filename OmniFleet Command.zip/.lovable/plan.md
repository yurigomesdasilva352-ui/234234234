
# VitaFleet EMS — Plano de construção

Sistema de demonstração visual (mock, sem backend) para impressionar empresários do setor de remoções médicas. Tudo client-side com dados simulados realistas e animações cinematográficas.

## Observação técnica importante
O template Lovable usa **TanStack Start + React + Tailwind v4 + shadcn/ui** (não Next.js). O resultado visual e de UX é equivalente — apenas o roteamento usa `src/routes/` (file-based). Sem Supabase nesta fase: tudo mock para foco em demo. Podemos plugar Lovable Cloud depois se quiser persistência real.

## Identidade visual (VitaFleet EMS)
- Tema dark premium: fundo `#070B14` / superfícies `#0E1525`
- Acento: azul hospitalar `#1E88FF`, cyan neon `#22D3EE`, verde status `#10F2B5`, âmbar alerta, vermelho emergência
- Tipografia: display `Space Grotesk`, body `Inter`, mono `JetBrains Mono` (métricas)
- Glassmorphism sutil, bordas 1px com glow, sombras suaves, micro-animações com Framer Motion
- Logo wordmark "VitaFleet" + ícone pulso/cruz médica em SVG inline
- Slogan: "Intelligent Emergency Fleet Operations"

## Estrutura de rotas (TanStack Start)
```
src/routes/
  __root.tsx              -> shell com sidebar + topbar
  index.tsx               -> Landing/login mock (CTA "Entrar na Central")
  central.tsx             -> Dashboard Operacional (mapa + feed)
  ocorrencias.tsx         -> Lista + criação + timeline
  ocorrencias.$id.tsx     -> Detalhe com timeline visual
  dispatch.tsx            -> Dispatch automático animado (IA)
  frota.tsx               -> Frota de ambulâncias + status
  equipes.tsx             -> Equipes/motoristas
  motorista.tsx           -> App mobile simulado (frame de celular)
  cliente.tsx             -> Portal do cliente (tracking)
  executivo.tsx           -> Dashboard executivo (BI)
  automacoes.tsx          -> Automações + notificações
```

## Telas e componentes

### 1. Central Operacional (`/central`)
- **Mapa** em tela cheia usando `react-leaflet` + tiles dark (CartoDB Dark Matter, sem chave). Marcadores customizados SVG para ambulâncias (animadas, com pulso), hospitais e ocorrências. Rotas desenhadas com polylines animadas. Movimento simulado por `setInterval` interpolando coordenadas.
- **Topbar de KPIs**: ambulâncias online, ocorrências ativas, tempo médio de resposta, SLA %, finalizadas hoje, equipes disponíveis — com mini-sparklines.
- **Painel lateral direito**: feed em tempo real (eventos rolam a cada 3–6s), com ícones coloridos e timestamp relativo.
- **Painel lateral esquerdo**: lista de ambulâncias com status (livre/em rota/no local/hospital), botão "focar no mapa".
- **Alertas flutuantes**: toasts elegantes ao surgir nova emergência.

### 2. Gestão de Ocorrências (`/ocorrencias`)
- Tabela premium com filtros por prioridade/status/região
- Botão "Nova Ocorrência" → Dialog em etapas (paciente, local com autocomplete mock, hospital destino, prioridade com cores, observações)
- Detalhe (`/ocorrencias/$id`) com **timeline vertical** animada dos 7 estágios, mini-mapa, dados do paciente, equipe alocada, ETA

### 3. Dispatch Automático (`/dispatch`)
- Animação cinematográfica: ocorrência entra → "IA analisando" com nós conectados pulsando → ranking de ambulâncias próximas (cards com distância/ETA/score) → seleção destacada com glow → "Despachado" com confete sutil
- Stepper visual e logs estilo terminal mostrando o "raciocínio"

### 4. App do Motorista (`/motorista`)
- Frame de iPhone centralizado, conteúdo 390x844
- Tela de chamado entrando (vibração visual), botões grandes Aceitar/Recusar, mapa de rota, status sequencial, checklist da ambulância (oxigênio, desfibrilador, etc.), botão SOS vermelho com glow pulsante

### 5. Portal do Cliente (`/cliente`)
- Form "Solicitar Remoção" minimalista
- Card de tracking: ambulância no mapa pequeno, ETA grande, foto/avatar da equipe, status atual, histórico de remoções anteriores

### 6. Dashboard Executivo (`/executivo`)
- Cards de KPI (faturamento mensal, remoções, ticket médio, SLA)
- Gráficos com **Recharts**: linha (remoções/dia), barras (top regiões), área (faturamento), radar (desempenho de equipes), heatmap horário×dia (CSS grid custom)
- Tabela de performance da frota

### 7. Automações (`/automacoes`)
- Cards de fluxos com toggle on/off: Dispatch IA, WhatsApp cliente, Alertas SLA, Manutenção preventiva, Documentos vencendo, Ambulância parada >30min, Equipe offline
- Stream de notificações com badges coloridos

## Dados mockados
`src/data/` com:
- `ambulances.ts` (12 viaturas: Alpha 01–06, Bravo 01–06, com placa, tipo USA/USB, equipe, status, coords)
- `crews.ts` (médicos, enfermeiros, socorristas com foto via `pravatar.cc`)
- `hospitals.ts` (8 hospitais reais de SP com coords)
- `incidents.ts` (gerador procedural de ocorrências)
- `events.ts` (gerador de eventos para o feed)
- `metrics.ts` (séries históricas para gráficos)
- Hook `useLiveSimulation()` que atualiza posições e gera eventos em intervalo

## Bibliotecas a adicionar
- `react-leaflet` + `leaflet`
- `framer-motion`
- `recharts`
- `date-fns`
- `clsx` (já presente via shadcn)

## Componentes compartilhados (`src/components/`)
- `AppSidebar` (shadcn sidebar) com navegação entre módulos + branding
- `Topbar` com busca, status do sistema (online), avatar admin
- `KpiCard`, `StatusBadge`, `LiveFeed`, `AmbulanceMarker`, `PriorityChip`, `TimelineStep`, `PhoneFrame`, `GlowCard`, `AnimatedNumber`

## Tokens & estilos
- Atualizar `src/styles.css`: tokens dark premium em oklch, gradientes `--gradient-primary`, `--gradient-glow`, sombras `--shadow-elegant`, `--shadow-neon`, animações utilitárias (pulse-glow, scan-line, marker-pulse)
- Carregar fontes via `<link>` no `head()` do `__root.tsx`

## Entrega faseada (em uma única build)
1. Tokens + sidebar + landing + branding
2. Mocks + hook de simulação
3. Central operacional com mapa
4. Ocorrências + timeline
5. Dispatch animado
6. Motorista + Cliente
7. Executivo (gráficos)
8. Automações + polish/animações finais

## Fora de escopo (mock apenas)
- Autenticação real, persistência, WhatsApp real, GPS real — tudo simulado de forma convincente. Posso ativar Lovable Cloud em iteração futura se quiser dados reais e multi-usuário.

Posso começar pelo módulo que preferir, ou implementar tudo em sequência. Confirma para eu construir?
